using StackEverythingRedux.Models;
using StackEverythingRedux.Network;
using StardewModdingAPI;
using StardewModdingAPI.Events;

namespace StackEverythingRedux
{
    internal class StackEverythingRedux : Mod
    {
        internal static Mod Instance;
        internal static ModConfig Config;

        public override void Entry(IModHelper helper)
        {
            Config = helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
        }

        private void OnGameLaunched(object sender, GameLaunchedEventArgs e)
        {
            GenericModConfigMenuIntegration.AddConfig(
                Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu"),
                ModManifest,
                Helper,
                Config
            );
        }

    }
}
